package cn.exitcode.day001.apicontect;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ApiContectApplicationTests {

    @Test
    void contextLoads() {
    }

}
