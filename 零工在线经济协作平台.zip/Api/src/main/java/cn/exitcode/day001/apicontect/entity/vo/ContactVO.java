package cn.exitcode.day001.apicontect.entity.vo;

import lombok.Data;

@Data
public class ContactVO {
    private int id;
    private String toid;
    private String num;
    private String toName;
    private String Qq;
}
