package cn.exitcode.day001.apicontect.entity.dto;

import lombok.Data;

@Data
public class PwdDTO {
    private String pwd;
    private String user;
}
