package cn.exitcode.day001.apicontect.entity.vo;

import lombok.Data;

@Data
public class ProRateVO {
    private String project;
    private String user;
    private String rate;
}
