package cn.exitcode.day001.apicontect.service;

import cn.exitcode.day001.apicontect.common.Result;
import cn.exitcode.day001.apicontect.entity.Projectrequire;
import cn.exitcode.day001.apicontect.entity.dto.EditRequireDTO;
import cn.exitcode.day001.apicontect.entity.dto.INTDTO;
import cn.exitcode.day001.apicontect.entity.dto.RateDTO;
import com.baomidou.mybatisplus.extension.service.IService;

/**
 * <p>
 *  服务类
 * </p>
 *
 * @author LingWei
 * @since 2025-01-19
 */
public interface ProjectrequireService extends IService<Projectrequire> {





}
