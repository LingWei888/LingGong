package cn.exitcode.day001.apicontect.entity.vo;

import lombok.Data;

@Data
public class UserVO {
    private String Qq;
    private int id;
    private String UserName;
}
