package cn.exitcode.day001.apicontect.entity.dto;

import lombok.Data;

@Data
public class LoginDTO {
    private String user;
    private String pwd;
}
