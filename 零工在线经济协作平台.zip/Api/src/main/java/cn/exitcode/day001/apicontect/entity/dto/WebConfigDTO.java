package cn.exitcode.day001.apicontect.entity.dto;

import lombok.Data;

@Data
public class WebConfigDTO {
    private String gonggao;
    private String keywords;
    private String description;
    private String title;
    private String sitename;
}
