package cn.exitcode.day001.apicontect.entity.dto;

import lombok.Data;

@Data
public class RateDTO {
    private int id;
    private int rating;
}
