package cn.exitcode.day001.apicontect.entity.dto;

import lombok.Data;

@Data
public class ApiDTO {
    private String appcode;
    private String api;
    private String smtp;
    private String port;
    private String mail;
    private String key;
}
