package cn.exitcode.day001.apicontect.common.JwtToken;

public class JwtClaimsConstant {

    public static final String LOGIN_ID = "loginId";
    public static final String USERNAME = "user";
    public static final String roleid = "0";

}

