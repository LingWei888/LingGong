
<script>
export default {
  name: 'AdminHome'
}
</script>
<template>
  <div>
    <h1>Admin Home</h1>
    <router-view></router-view>
  </div>
</template>



<style scoped>

</style>